import csv
from csv import DictReader

input_file = csv.DictReader(open("event_datafile_new.csv"))

max_age = None
oldest_person = None
# for row in input_file:
#    print(row["artist"])

file = "event_datafile_new.csv"
with open(file, 'r') as f:
    csvreader = csv.reader(f)
    next(csvreader) # skip header
    # print("next(csvreader) {0}".format(next(csvreader)))
    print("len(list(csvreader) {0})".format(len(list(csvreader))))
    # print(type(csvreader))
    # csv_dict = DictReader(f)
    # for row in csv_dict:
    #     print(row)
    for line in csvreader:
        print("IN LOOP")
# ## TO-DO: Assign the INSERT statements into the `query` variable
#         query = "INSERT INTO music_info (artist, song, length, sessionid, itemInSession)"
#         query = query + "VALUES (%s, %s, %s, %s, %s)"
#         ## TO-DO: Assign which column element should be assigned for each column in the INSERT statement.
#         ## For e.g., to INSERT artist_name and user first_name, you would change the code below to `line[0], line[1]`
# #         if q % 3 == 0:
# #             print(line[0], line[9], line[5], line[8], line[3])
#         session.execute(query, (line[0], line[9], line[5], line[8], line[3]))
print("OUT OF LOOP       \n\n\n")

import csv
with open(file, 'r',encoding = 'utf8') as file:
    reader = csv.reader(file)
    next(file)
    i = 0
    for line in reader:
        # pass
        print(i)
        i += 1
    print(i)