import cassandra
import pandas as pd
import re
import os
import glob
import numpy as np
import json
import csv
from sql_query_helpers import *
from sql_queries import *

from cassandra.cluster import Cluster
def read_csv(filepath, logging=False):
    """
    Reads a JSON file from a filepath and returns a list of files/
    filepath: the filepath of the file to be opened.
    logging: a boolean that determines if logs are outputted.
    returns: full_data_rows_list: a list of all rows for JSON files.
    """
    # event_data_filepath = '/data engineering/Project2/event_data'
    filepath = os.getcwd() + filepath
    for root, dirs, files in os.walk(filepath):
    # join the file path and roots with the subdirectories using glob
        file_path_list = glob.glob(os.path.join(root,'*'))
        # print("file_path_list {0}\n".format(file_path_list))
    # initiating an empty list of rows that will be generated from each file
    full_data_rows_list = []       
    # for every filepath in the file path list 
    for f in file_path_list:
    # reading csv file 
        with open(f, 'r', encoding = 'utf8', newline='') as csvfile: 
            # creating a csv reader object 
            csvreader = csv.reader(csvfile) 
            next(csvreader) 
    # extracting each data row one by one and append it
            for line in csvreader:
                full_data_rows_list.append(line)              
    if logging:
        # uncomment the code below if you would like to get total number of rows 
        print("Number of rows in the CSV file: {0}".format(len(full_data_rows_list)))
        # uncomment the code below if you would like to check to see what the list of event data rows will look like
        # print(full_data_rows_list)
    return full_data_rows_list

def create_csv(full_data_rows_list, logging=False):
    """
    Creats a CSV file from JSON files.
    full_data_rows_list: a list of files to be processed.
    logging: a boolean that determines if logs are outputted.
    returns: the number of rows
    """
    # creating a smaller event data csv file called event_datafile_full csv that will be used to insert data into the \
    # Apache Cassandra tables
    csv.register_dialect('myDialect', quoting=csv.QUOTE_ALL, skipinitialspace=True)

    with open('data engineering/Project2/event_datafile_new.csv', 'w', encoding = 'utf8', newline='') as f:
        writer = csv.writer(f, dialect='myDialect')
        writer.writerow(['artist','firstName','gender','itemInSession','lastName','length',\
                    'level','location','sessionId','song','userId'])
        for row in full_data_rows_list:
            if (row[0] == ''):
                continue
            writer.writerow((row[0], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[12], row[13], row[16]))

    # check the number of rows in your csv file
    num_rows = 0
    with open('event_datafile_new.csv', 'r', encoding = 'utf8') as f:
        num_rows = format(sum(1 for line in f))
        if logging:    
            print(" Lines in new CSV{0}".format(sum(1 for line in f)))
    return int(num_rows)
    
### Cassandra 
# This should make a connection to a Cassandra instance your local machine 
# (127.0.0.1)
def connect_to_cassandra(ip):
    """
    connects to a cassandra database
    ip: the IP address of the cluster
    """
    try: 
        # cluster = Cluster(['127.0.0.1']) #If you have a locally installed Apache Cassandra instance
        cluster = Cluster([ip]) #If you have a locally installed Apache Cassandra instance
        session = cluster.connect()
    except Exception as e:
        print("Error connecting to cassandra {0}".format(e))
    # To establish connection and begin executing queries, need a session
    session = cluster.connect()

    try:
        session.execute("""
        CREATE KEYSPACE IF NOT EXISTS udacity 
        WITH REPLICATION = 
        { 'class' : 'SimpleStrategy', 'replication_factor' : 1 }""")
    except Exception as e:
        print("Error creating keyspace {0}".format(e))
    try:
        session.set_keyspace('udacity')
    except Exception as e:
        print("Error setting the keyspace {0}".format(e))
    return session

def get_file_path(event_data_filepath):
    """
    gets the full file path for a for a directory
    """
    event_data_filepath = '/data engineering/Project2/event_data'
    filepath = os.getcwd() + event_data_filepath
    return filepath

def main():
    """
    the main class. runs the program
    """
    ##### String Vars #####
    ip = '127.0.0.1'
    filepath = '/data engineering/Project2/event_data'
    file = 'event_datafile_new.csv'
    tablename = "music_info"
    tablename2 = "user_info_by_session"
    tablename3 = "user_info_by_song"
    
    ##### read the csv #####
    full_data_rows_list = read_csv(filepath)
    ##### write the new event data file #####
    csv = create_csv(full_data_rows_list)
    if csv > 0:
        print("csv created with number of lines == {}\n".format(csv))
    else:
        print("An issue has occured with the csv creation. \
            The number of lines == {}".format(csv))
        
    ##### connect to cassandra #####
    session = connect_to_cassandra(ip)
    ##### create the table for query 1 #####
    
    ### Table 1 ###
    table1_columns = "(artist text, song text, length decimal, sessionid int, \
        itemInSession int, PRIMARY KEY (sessionid, iteminsession, artist))"
    create_table(session, tablename, table1_columns)
    
    ##### INSERT data #####
    insert_data(session, tablename, file)
    
    # get number of rows in table
    rows =  count_star(session, tablename)
    if int(rows) > 0:
        print("{0} rows in {1}".format(int(rows), tablename))
    
    # query1 and print results
    print("\nQuery 1")
    select_1(session, query1)
    
    print("\nQuery 2")
    #### table 2
    table2_columns = "(userid int,sessionid int, itemInSession int, artist text, \
        song text, firstName text, lastName text,\
        PRIMARY KEY ((userid, sessionid), iteminsession)) \
        WITH CLUSTERING ORDER BY (iteminsession ASC);"
    create_table(session, tablename2, table2_columns)
    query_test = "SELECT userid FROM {0}".format(tablename2)
    r = session.execute(query_test)
    for i in r:
        print("query_test {0".format(i))
    insert_data_table_2(session, tablename2, file)
    select_query2 = "SELECT artist, song, firstname, lastname,itemInSession \
        FROM {0} WHERE sessionID=182 AND userid=10".format(tablename2)
    select_2(session, query2)
    
    print("\nQuery 3")
    #### table 3
    table3_columns = "(song text, userid int, firstname text, lastname text,\
            PRIMARY KEY (song, firstname, lastname)) \
            WITH CLUSTERING ORDER BY (firstname ASC, lastname ASC);"
    create_table(session, tablename3, table3_columns)
    insert_data_table_3(session, tablename3, file)
    select_3(session, query3)
      
if __name__ == "__main__":
    main()