# Query 1
query1 = """SELECT artist, \
            song, \
            length \
            FROM music_info \
            WHERE sessionid = 338 \
            AND itemInSession = 4"""

query2 = """SELECT artist, song, firstname, lastname,itemInSession \
        FROM user_info_by_session \
        WHERE sessionID=182 \
        AND userid=10"""
            
query3 = """SELECT song, firstname, lastname 
            FROM user_info_by_song 
            WHERE song = 'All Hands Against His Own'"""
            

        