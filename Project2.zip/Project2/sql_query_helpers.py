import csv
import pandas as pd

# Pandas
def pandas_worker(data, columns):
    """
    creates and prints a Pandas Dataframe representation of the data.
    data: the data to be added.
    columns: the column names
    returns: df: a dataframe
    """
    dict = {}
    for i in range(len(columns)):
        dict[columns[i]] =  data[i]
    df = pd.DataFrame(dict, columns=columns, index=[0])
    print("\n{0}\n".format(df))
    return df
    

# CSV Helper
def readfile(file):
    """
    Open and reads a CSV file.
    file: the file to be opened
    """
    with open(file, 'r',encoding = 'utf8') as file:
        reader = csv.reader(file)
        next(file)
    return reader

# DROP Table
def drop_table(session, tablename, logging=False):
    """
    Drops a SQL table. 
    sessin: a cursor session.
    tablename: the table name to be dropped
    returns: A boolean for whether an exception ocurred.
    """
    query = "DROP TABLE IF EXISTS {0} ".format(tablename)
    try:
        session.execute(query)
        if logging:
            print("Attempting to Drop {0}".format(tablename))
        return True
    except Exception as e:
        print("Error DROPPING table {0} - {1} ".format(tablename, e)) 
        return False 

# CREATE Table
def create_table(session, tablename, column_info, logging=False):
    """
    Creates a new SQL table.
    sessin: a cursor session.
    tablename: the table name to be created
    column_info: a list of column names for the table
    logging: whether info messages should be printed.
    """
    if logging:
        print("creating table, {0}".format(tablename))
    drop_table(session, tablename)
    query = "CREATE TABLE IF NOT EXISTS {0}  {1}".format(tablename, column_info)
    try:
        session.execute(query)
    except Exception as e:
        print("Error creating table {0} - {1} ".format(tablename, e))                    

# INSERT RECORDS

## Query 1
def insert_data(session, tablename, file, logging=False):
    """
    Inserts data into a sql table.
    sessin: a cursor session.
    tablename: the table name to have data inserted into.
    file: the file to be opened by the CSV Reader.
    logging: whether info messages should be printed.
    """
    if logging:
        print("inserting data into {0}".format(tablename))
    file = "event_datafile_new.csv"
    try:
        with open(file, 'r',encoding = 'utf8') as file:
            reader = csv.reader(file)
            next(file)
            for line in reader:
                query = "INSERT INTO music_info (artist, song, length, sessionid, itemInSession)"
                query = query + "VALUES (%s, %s, %s, %s, %s)"
                session.execute(query, (line[0], line[9], float(line[5]), int(line[8]), int(line[3])))
    except Exception as e:
        print("Error opening  CSV or inserting data for {0} - {1}".format(tablename, e))
                
def insert_data_table_2(session, tablename, file, logging=False):
    """
    Inserts data into a sql table.
    sessin: a cursor session.
    tablename: the table name to have data inserted into.
    file: the file to be opened by the CSV Reader.
    logging: whether info messages should be printed.
    
    """
    if logging:
        print("inserting data into {0}".format(tablename))
    try:
        with open(file, 'r',encoding = 'utf8') as file:
            reader = csv.reader(file)
            next(file)
            for line in reader:
                query = "INSERT INTO user_info_by_session (userid,sessionid, itemInSession,artist, song, firstName, lastName)"
                query = query + "VALUES (%s, %s, %s, %s, %s, %s, %s)"
                session.execute(query, (int(line[10]), int(line[8]), int(line[3]),line[0], line[9], line[1], line[4]))
    except Exception as e:
        print("Error opening  CSV or inserting data for {0} - {1}".format(tablename, e))        

def insert_data_table_3(session, table, file, logging=False):
    """
    Inserts data into a sql table.
    sessin: a cursor session.
    tablename: the table name to have data inserted into.
    file: the file to be opened by the CSV Reader.
    logging: whether info messages should be printed.
    """
    if logging:
        print("inserting data into {0}".format(table))
    error_list = []
    try:
        with open(file, 'r',encoding = 'utf8') as file:
            reader = csv.reader(file)
            next(file)
            for line in reader:
                try:
                    query = "INSERT INTO {0} (song, firstName, lastName)".format(table)
                    query = query + "VALUES (%s, %s, %s)"
                    session.execute(query, (line[9], line[1], line[4]))
                except Exception as e:
                    error_list.append(e)
    except Exception as e:
        print("Error opening  CSV or inserting data for {0} - {1}".format(table, e))                        

# SELECT
def select_1(session, query):
    """
    Performs a select query for problem 1.
    session: a cursor session
    query: a SQL query to run
    """
    column_labels = (['artist', 'song','length'])
    try:
        rows = session.execute(query)
    except Exception as e:
        print("Error  {0} - {1} ".format(query, e))
    try:
        for row in rows:
            # print("{0},{1},{2}".format(row.artist, row.song, row.length))
            df = pandas_worker([row.artist, row.song, row.length], column_labels)
    except Exception as e:
            print("Error selecting from table {0} {1}".format(query, e)) 
            
def select_2(session, query):
    """
    Performs a select query for problem 2.
    session: a cursor session
    query: a SQL query to run
    """
    column_labels = (['artist', 'song','firstname', 'lastname', 'iteminsession'])
    try:
        rows = session.execute(query)
        for row in rows:
            # print("{0}, {1}, {2}, {3}, {4}".format(row.artist, row.song, row.firstname, row.lastname, row.iteminsession))
            df = pandas_worker(([row.artist, row.song, row.firstname, row.lastname, row.iteminsession]),column_labels)
    except Exception as e:
        print("Error selecting: {0} table {1} ".format(query,e))  
        
def select_3(session, query):
    """
    Performs a select query for problem 3.
    session: a cursor session
    query: a SQL query to run
    """
    column_labels = (['song', 'firstname', 'lastname'])
    try:
        rows = session.execute(query)
        session.execute(query)
        for row in rows:
            # print("{0}, {1}, {2}".format(row.song, row.firstname, row.lastname))
            df = pandas_worker(([row.song, row.firstname, row.lastname]), column_labels)
    except Exception as e:
        print("Error selecting from table {0} {1}".format(query, e))  

    
# COUNT

def count_star(session, tablename):
    """
    Performs a SELECT COUNT(*) query on a table.
    session: a cursor session
    tablename: the table name to query
    """
    results = 0
    try:
        rows = session.execute("SELECT COUNT(*) FROM {0}".format(tablename))
        for row in rows:
            # print("SELECT COUNT(*) FROM {0} = {1}".format(row, tablename))
            results = row.count
    except Exception as e:
        print("Error selecting * FROM {0} - {1} ".format(tablename, e)) 
        results =  0
    return results